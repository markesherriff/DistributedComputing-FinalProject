import java.io.Serializable;

public class Home implements Serializable {
    public String NewUser() { return "/spotlight.xhtml?faces-redirect=true"; }

    public String AllUsers() { return "/datatable.xhtml?faces-redirect=true"; }
}
