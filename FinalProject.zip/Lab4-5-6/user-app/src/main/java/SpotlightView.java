import service.impl.UserService;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;

@Named
@RequestScoped
public class SpotlightView implements Serializable {

    @Inject
    private UserService userService;

    private String firstName;

    private String lastName;

    private String dob;

    private String email;

    private String occupation;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String cancel() { return "/home.xhtml?faces-redirect=true"; }

    public String save() {
        userService.addUser(firstName, lastName, dob, email, occupation);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Successfully Registered"));
        setFirstName(null);
        setLastName(null);
        setDob(null);
        setEmail(null);
        setOccupation(null);
        return "/home.xhtml?faces-redirect=true";
    }
}